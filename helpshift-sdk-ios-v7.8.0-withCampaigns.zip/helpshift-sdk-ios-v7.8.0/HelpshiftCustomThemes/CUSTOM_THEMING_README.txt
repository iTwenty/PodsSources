Refer https://developers.helpshift.com/ios/design/#skinning for theming the SDK.
