//
// Support.h
// Created for Helpshift in 2020
// Copyright © 2020 Helpshift. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Helpshift.
FOUNDATION_EXPORT double HelpshiftVersionNumber;

//! Project version string for Helpshift.
FOUNDATION_EXPORT const unsigned char HelpshiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import "PublicHeader.h"
#import "HelpshiftCore.h"
#import "HelpshiftSupport.h"
